/*****************************************************************/
/* gouraudshading.h                                              */
/*****************************************************************/

/* Header f�r Gouraudshading */



#ifndef __GOURAUDSHADING_H__
#define __GOURAUDSHADING_H__

void Gouraudshading(Triangle3dType Triangle3d, Triangle2dType Triangle2d);

/*****************************************************************/

#endif