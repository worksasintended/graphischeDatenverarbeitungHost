/*****************************************************************/
/* backface.h                                                    */
/*****************************************************************/


#ifndef __BACKFACE_H__
#define __BACKFACE_H__

int Backface(Triangle3dType Triangle3d, ObjectPoint Eye, float *gray);

/*****************************************************************/

#endif