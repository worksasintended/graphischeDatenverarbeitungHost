/*****************************************************************/
/* flatshading.h                                                 */
/*****************************************************************/

/* Header f�r Flatshading */

#ifndef __FLATSHADING_H__
#define __FLATSHADING_H__

void Flatshading(Triangle2dType Triangle2d, float gray);

/*****************************************************************/

#endif