/* Header f�r Teapot-Projekte */
//#pragma once

#ifndef TEAPOTDATA_H
#define TEAPOTDATA_H

#include "projection.h"

#define NumTriangle 1504

extern Triangle3dType teapot3d[NumTriangle];

#endif