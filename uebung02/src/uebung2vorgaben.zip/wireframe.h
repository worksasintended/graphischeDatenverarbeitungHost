/*****************************************************************/
/* wireframe.h                                                       */
/*****************************************************************/

/* Header f�r Linie zeichnen */


#ifndef __WIREFRAME_H__
#define __WIREFRAME_H__

void Wireframe(Triangle2dType Triangle2d);

/*****************************************************************/

#endif